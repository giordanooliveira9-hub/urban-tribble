package br.com.gb.vozinteligente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var answer: TextView
    private lateinit var listenButton: Button
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null
    private var apiUrl = "https://api.openai.com/v1/chat/completions"
    private var apiKey = ""
    private var model = "gpt-4o-mini"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        speech = if (SpeechRecognizer.isRecognitionAvailable(this)) SpeechRecognizer.createSpeechRecognizer(this) else null
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo..." }
            override fun onBeginningOfSpeech() { status.text = "Pode falar" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Interpretando..." }
            override fun onError(error: Int) { status.text = "Não consegui entender. Toque para tentar novamente." }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                transcript.text = "Você: $phrase"
                handleCommand(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(8, 10, 8, 10) }
        layout.addView(label("GB VOZ INTELIGENTE", 26f, 0xFF55B7FF.toInt()))
        layout.addView(label("Seu celular obedecendo à sua voz", 15f, 0xFFCBD5E1.toInt()))
        listenButton = Button(this).apply {
            text = "🎙 FALAR COM GB"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        layout.addView(listenButton)
        status = label("Pronto para ouvir", 14f, 0xFF93C5FD.toInt())
        layout.addView(status)
        transcript = label("Sua fala aparecerá aqui.", 16f)
        layout.addView(transcript)
        answer = label("Olá! Sou o GB. Toque no microfone e diga um comando.", 16f)
        layout.addView(answer)
        val access = Button(this).apply {
            text = "Ativar controle por acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(access)
        val config = Button(this).apply {
            text = "Configurar assistente inteligente (API)"
            setOnClickListener { showApiDialog() }
        }
        layout.addView(config)
        layout.addView(label("Comandos: abrir WhatsApp • voltar • início • rolar para baixo • tocar em pesquisar • que horas são?", 12f, 0xFF94A3B8.toInt()))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val recognizer = speech ?: run { status.text = "Reconhecimento de voz indisponível neste aparelho."; return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale um comando em português")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.startListening(intent)
    }

    private fun speak(text: String) {
        answer.text = text
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gb_response")
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.lowercase(Locale("pt", "BR")).trim()
        when {
            cmd.contains("voltar") -> perform(GBAccessibilityService.ACTION_BACK, "Voltando.")
            cmd.contains("tela inicial") || cmd == "início" || cmd == "inicio" ->
                perform(GBAccessibilityService.ACTION_HOME, "Voltando para a tela inicial.")
            cmd.contains("visão geral") || cmd.contains("aplicativos recentes") ->
                perform(GBAccessibilityService.ACTION_RECENTS, "Abrindo aplicativos recentes.")
            cmd.contains("rolar para baixo") || cmd.contains("descer a página") ->
                perform(GBAccessibilityService.ACTION_SCROLL_DOWN, "Rolando para baixo.")
            cmd.contains("rolar para cima") || cmd.contains("subir a página") ->
                perform(GBAccessibilityService.ACTION_SCROLL_UP, "Rolando para cima.")
            cmd.startsWith("abrir ") || cmd.startsWith("abra ") -> openApp(cmd.removePrefix("abrir ").removePrefix("abra ").trim())
            cmd.contains("que horas") -> speak("Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(java.util.Date()))
            cmd.contains("parar") || cmd.contains("silêncio") -> { tts.stop(); speak("Parei.") }
            else -> askAssistant(raw)
        }
    }

    private fun perform(action: Int, response: String) {
        val service = GBAccessibilityService.instance
        if (service == null) speak("Para controlar a tela, ative o serviço de acessibilidade do GB nas configurações.")
        else { service.performGBAction(action); speak(response) }
    }

    private fun openApp(name: String) {
        val candidates = packageManager.getInstalledApplications(0)
        val found = candidates.firstOrNull {
            packageManager.getApplicationLabel(it).toString().lowercase().contains(name)
        }
        if (found == null) { speak("Não encontrei o aplicativo $name."); return }
        val launch = packageManager.getLaunchIntentForPackage(found.packageName)
        if (launch != null) { startActivity(launch); speak("Abrindo ${packageManager.getApplicationLabel(found)}.") }
        else speak("Esse aplicativo não pode ser aberto por aqui.")
    }

    private fun askAssistant(question: String) {
        if (apiKey.isBlank()) {
            speak("Entendi: $question. Para respostas inteligentes de conversa, configure uma chave de API nas configurações do assistente. Os comandos básicos funcionam sem ela.")
            return
        }
        status.text = "Consultando o assistente..."
        thread {
            try {
                val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    doOutput = true
                }
                val payload = JSONObject().put("model", model).put("messages", org.json.JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "Você é GB, assistente em português brasileiro. Responda de forma clara, breve e segura. Não afirme que executou ações no celular se não executou."))
                    .put(JSONObject().put("role", "user").put("content", question)))
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("Erro HTTP ${conn.responseCode}")
                val result = JSONObject(body).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                runOnUiThread { status.text = "Pronto"; speak(result) }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Assistente indisponível"; speak("Não consegui acessar o serviço inteligente. Verifique a internet e a configuração da API.") }
            }
        }
    }

    private fun showApiDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 8) }
        val key = EditText(this).apply { hint = "Chave de API"; setSingleLine(true); setText(apiKey) }
        val modelField = EditText(this).apply { hint = "Modelo"; setSingleLine(true); setText(model) }
        val endpoint = EditText(this).apply { hint = "Endpoint compatível"; setSingleLine(true); setText(apiUrl) }
        box.addView(key); box.addView(modelField); box.addView(endpoint)
        android.app.AlertDialog.Builder(this).setTitle("Assistente inteligente")
            .setMessage("Informe sua própria chave de API. Ela fica apenas nesta sessão do aplicativo.")
            .setView(box).setPositiveButton("Salvar") { _, _ ->
                apiKey = key.text.toString().trim()
                model = modelField.text.toString().trim().ifBlank { "gpt-4o-mini" }
                apiUrl = endpoint.text.toString().trim().ifBlank { "https://api.openai.com/v1/chat/completions" }
                speak("Configuração atualizada.")
            }.setNegativeButton("Cancelar", null).show()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("pt", "BR")
    }
    override fun onDestroy() {
        speech?.destroy()
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }
}
