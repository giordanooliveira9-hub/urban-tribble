# GB Voz Inteligente — projeto Android inicial

Aplicativo Android nativo em Kotlin com:
- reconhecimento de fala configurado para `pt-BR` via serviço de reconhecimento instalado no Android;
- resposta falada com Android TextToSpeech;
- comandos locais: abrir aplicativo, voltar, tela inicial, recentes, rolagem e hora;
- serviço de acessibilidade para ações globais;
- modo de conversa via API compatível com OpenAI Chat Completions, configurável pelo usuário.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `GB-Voz-Inteligente` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em um celular Android (API 26 ou superior).

## Configurar no celular
1. Conceda a permissão de microfone.
2. Toque em “Ativar controle por acessibilidade” e habilite GB Voz Inteligente.
3. Para conversar com IA, toque em “Configurar assistente inteligente” e informe endpoint, modelo e sua própria chave de API.

## Limitações importantes desta versão
- É um MVP de código-fonte, não um APK compilado e assinado.
- O reconhecimento de fala depende do mecanismo de voz instalado no Android e da disponibilidade de português brasileiro.
- A conversa com IA exige internet e chave de API própria; custos e limites dependem do provedor.
- A chave é mantida apenas em memória nesta versão e será perdida ao fechar o aplicativo. Não use esta versão como cofre de credenciais.
- O serviço de acessibilidade requer ativação manual pelo usuário e deve ser usado apenas para comandos que o próprio usuário iniciar. Não há escuta permanente em segundo plano.
- Não implementa envio automático de mensagens, leitura de conteúdo privado ou execução irrestrita de ações. Essas funções exigem desenho adicional, permissões e confirmação explícita.
- O serviço de acessibilidade fornece apenas ações de navegação e rolagem nesta primeira versão.

## Próximas etapas recomendadas
Adicionar confirmação antes de chamadas/ações sensíveis, armazenamento seguro da configuração, comando de ativação, mais intents de aplicativos, testes em diferentes fabricantes e revisão de privacidade.


## Compilar pela internet (GitHub Actions)
O projeto inclui `.github/workflows/build-apk.yml`. Para usar:
1. Entre em https://github.com e crie uma conta ou entre na sua.
2. Crie um repositório novo, por exemplo `gb-voz-inteligente` (pode ser privado).
3. Extraia este ZIP no seu celular/computador.
4. Envie para o repositório os arquivos e pastas que estão dentro de `GB-Voz-Inteligente`, incluindo a pasta oculta `.github`.
5. Abra a aba **Actions**, selecione **Build GB Voz Inteligente APK** e toque em **Run workflow** (ou aguarde o build após enviar os arquivos para `main`).
6. Quando terminar com sucesso, abra a execução e baixe o artefato `GB-Voz-Inteligente-debug`. Dentro dele estará `app-debug.apk`.
7. No Android, abra o APK baixado e autorize a instalação desta fonte, se solicitado.

O APK debug é para teste e não é uma versão pronta para publicar na Play Store. Não coloque chaves de API no repositório.
